<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Nota Tutup Kasir</title>

    <?php
    $style = '
    <style>
        * {
            font-family: "consolas", sans-serif;
        }
        p {
            display: block;
            margin: 3px;
            font-size: 10pt;
        }
        table td {
            font-size: 9pt;
        }
        .text-center {
            text-align: center;
        }
        .text-right {
            text-align: right;
        }

        @media print {
            @page {
                margin: 0;
                size: 75mm 
    ';
    ?>
    <?php 
    $style .= 
        ! empty($_COOKIE['innerHeight'])
            ? $_COOKIE['innerHeight'] .'mm; }'
            : '}';
    ?>
    <?php
    $style .= '
            html, body {
                width: 70mm;
            }
            .btn-print {
                display: none;
            }
        }
    </style>
    ';
    ?>

    <?php echo $style; ?>

</head>
<body onload="window.print()">
    <button class="btn-print" style="position: absolute; right: 1rem; top: rem;" onclick="window.print()">Print</button>
    <div class="text-center">
        <h3 style="margin-bottom: 5px;"><?php echo e(strtoupper($setting->nama_perusahaan)); ?></h3>
        <p><?php echo e(strtoupper($setting->alamat)); ?></p>
        <p class="text-center">No Telepon : <?php echo e(strtoupper($setting->telepon)); ?></p>
        <p class="text-center">No Whatsapp : <?php echo e(strtoupper($setting->wa)); ?></p>
    </div>
    <br>
    <p class="text-center"> * * * * Laporan Tutup Kasir * * * * </p>
    <br>

    <table width="100%" style="border: 0;">
        <tr>
            <td>Shift :</td>
            <td class="text-right"><?php echo e($kasir->shift->nama_shift); ?></td>
        </tr>
        <tr>
            <td>Petugas :</td>
            <td class="text-right"><?php echo e($kasir->petugas); ?></td>
        </tr>
        <tr>
            <td>Dibuka Oleh :</td>
            <td class="text-right"><?php echo e($kasir->buka->name); ?></td>
        </tr>
        <tr>
            <td>Waktu Buka :</td>
            <td class="text-right"><?php echo e($kasir->waktu_buka); ?></td>
        </tr>
        <tr>
            <td>Ditutup Oleh :</td>
            <td class="text-right"><?php echo e($kasir->tutup->name); ?></td>
        </tr>
        <tr>
            <td>Waktu tutup :</td>
            <td class="text-right"><?php echo e($kasir->waktu_tutup); ?></td>
        </tr>
    </table>
   
    <p class="text-center">============================</p>
    <table width="100%" class="table-bordered table-striped" >
        <tr>
            <td>Modal:</td>
            <td class="text-right"><?php echo e(format_uang($kasir->saldo_awal)); ?></td>
        </tr>
        <tr>
            <td>Total Penjualan Tunai</td>
            <td class="text-right"><?php echo e(format_uang($kasir->tunai)); ?></td>
        </tr>
        <tr>
            <td>Total Penjualan NonTunai </td>
            <td class="text-right"><?php echo e(format_uang($kasir->nontunai)); ?></td>
        </tr>
        
        <?php $__currentLoopData = $metode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $me): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($me->metode); ?> :</td>
            <td class="text-right"><?php echo e(format_uang($me->id)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <tr>
            <td>Total Semua Penjualan</td>
            <td class="text-right"><?php echo e(format_uang($kasir->total_penjualan)); ?></td>
        </tr>
        <tr>
            <td>Total Pengeluaran:</td>
            <td class="text-right"><?php echo e(format_uang($kasir->pengeluaran)); ?></td>
        </tr>
        <tr>
            <td>Total Saldo </td>
            <td class="text-right"><?php echo e(format_uang($kasir->saldo_akhir)); ?></td>
        </tr>
        
       
       
    </table>
    
    <p class="text-center">========== TERIMA KASIH ==========</p>
    <p class="text-center">Di print pada <?php echo e($waktu); ?></p>
   

    <script>
        let body = document.body;
        let html = document.documentElement;
        let height = Math.max(
                body.scrollHeight, body.offsetHeight,
                html.clientHeight, html.scrollHeight, html.offsetHeight
            );

        document.cookie = "innerHeight=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
        document.cookie = "innerHeight="+ ((height + 50) * 0.264583);
    </script>
</body>
</html><?php /**PATH C:\laragon\www\apotek\resources\views/penjualan/nota_tutup.blade.php ENDPATH**/ ?>