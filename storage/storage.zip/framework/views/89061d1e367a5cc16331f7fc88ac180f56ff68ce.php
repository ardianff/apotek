<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo e(url(auth()->user()->foto ?? '')); ?>" class="img-circle img-profil" alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php echo e(auth()->user()->name); ?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>
        
        <!-- /.search form -->
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">
            <li>
                <a href="<?php echo e(route('dashboard')); ?>">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
            </li>

            <?php if(auth()->user()->level == 1): ?>

            <li class="header">TRANSAKSI</li>
          
         
            
            <?php if(!$kasir): ?>
                
            <li>
                <a href="<?php echo e(route('shift.buka')); ?>" >
                    <i class="fa fa-folder-open" aria-hidden="true"></i> <span>Buka Kasir</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if($kasir): ?>
                
            <?php if($kasir->status =='tutup'): ?>
            <li>
                <a href="<?php echo e(route('shift.buka')); ?>" >
                    <i class="fa fa-folder-open" aria-hidden="true"></i> <span>Buka Kasir</span>
                </a>
            </li>
            <?php endif; ?>
            <?php endif; ?>
                
            <?php if($kasir->status =='buka'): ?>
            <li>
                <a href="<?php echo e(route('shift.get_kasir',$kasir->id)); ?>" >
                    <i class="fa fa-folder-o" aria-hidden="true"></i> <span>Tutup Kasir</span>
                </a>
            </li>
            
            <?php endif; ?>
            <?php if($kasir): ?>
                
            <?php if($kasir->status =='buka'): ?>
            
            <li>
                <a href="<?php echo e(route('transaksi.index')); ?>" >
                    <i class="fa fa-cart-arrow-down"></i> <span>Transaksi Aktif</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('transaksi.baru')); ?>" target="_blank">
                    <i class="fa fa-cart-arrow-down"></i> <span>Transaksi Baru</span>
                </a>
            </li>
                   
            <li>
                <a href="<?php echo e(route('pengeluaran.index')); ?>">
                    <i class="fa fa-money"></i> <span>Pengeluaran</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('pembelian.index')); ?>">
                    <i class="fa fa-download"></i> <span>Pembelian</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('penjualan.index')); ?>">
                    <i class="fa fa-upload"></i> <span>Penjualan</span>
                </a>
            </li>
            <li>
                <a href="">
                    <i class="fa fa-refresh" ></i> <span> Retur Penjualan</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('retur_pembelian.index')); ?>">
                    <i class="fa fa-refresh" ></i> <span> Retur Pembelian</span>
                </a>
            </li>
            <?php endif; ?>
            <?php endif; ?>
            <li class="header">REPORT</li>
            <li>
                <a href="<?php echo e(route('pershift.index')); ?>">
                    <i class="fa fa-file-pdf-o"></i> <span>Laporan Penjualan per shift</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('laporan.index')); ?>">
                    <i class="fa fa-file-pdf-o"></i> <span>Laporan Hutang</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('laporan.piutang')); ?>">
                    <i class="fa fa-file-pdf-o"></i> <span>Laporan Piutang</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('laporan.index')); ?>">
                    <i class="fa fa-file-pdf-o"></i> <span>Laporan Laba Rugi</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('laporan.index')); ?>">
                    <i class="fa fa-file-pdf-o"></i> <span>Laporan Cashflow</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('laporan.index')); ?>">
                    <i class="fa fa-file-pdf-o"></i> <span>Laporan Neraca</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('laporan.index')); ?>">
                    <i class="fa fa-file-pdf-o"></i> <span>Laporan Perubahan Modal</span>
                </a>
            </li>
            <li class="header">MASTER</li>
            <li>
                <a href="<?php echo e(route('produk.index')); ?>">
                    <i class="fa fa-plus-square"></i> <span> master Obat</span>
                </a>
            </li>
           
            <li>
                <a href="<?php echo e(route('racikan.index')); ?>">
                    <i class="fa fa-plus-square"></i> <span> Racikan Obat</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('metode.index')); ?>">
                    <i class="fa fa-medkit"></i> <span>Metode Pembayaran</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('transfer.index')); ?>">
                    <i class="fa fa-medkit"></i> <span> Transfer Obat</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('kategori.index')); ?>">
                    <i class="fa fa-tag"></i> <span>Kategori Obat</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('golongan.index')); ?>">
                    <i class="fa fa-tags"></i> <span>Golongan Obat</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('jenis.index')); ?>">
                    <i class="fa fa-cubes"></i> <span>Jenis Obat</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('lokasi.index')); ?>">
                    <i class="fa fa-map-marker"></i> <span>Lokasi Obat</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('jasa.index')); ?>">
                    <i class="fa fa-stethoscope"></i> <span>Jasa dan embalase</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('apoteker.index')); ?>">
                    <i class="fa fa-user-md"></i> <span>Apoteker</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('diskon.index')); ?>">
                    <i class="fa fa-user-circle"></i> <span>Diskon</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('member.index')); ?>">
                    <i class="fa fa-id-card"></i> <span>Member</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('supplier.index')); ?>">
                    <i class="fa fa-truck"></i> <span>Supplier</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('supplier.index')); ?>">
                    <i class="fa fa-bank"></i> <span>Pabrik</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('supplier.index')); ?>">
                    <i class="fa fa-building-o"></i> <span>Gudang</span>
                </a>
            </li>
            <li class="header">SYSTEM</li>
            <li>
                <a href="<?php echo e(route('user.index')); ?>">
                    <i class="fa fa-users"></i> <span>User</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route("setting.index")); ?>">
                    <i class="fa fa-cogs"></i> <span>Pengaturan</span>
                </a>
            </li>
            <?php else: ?>
            <?php if($kasir): ?>

            <?php if($kasir->status =='buka'): ?>

            <li>
                <a href="<?php echo e(route('transaksi.index')); ?>">
                    <i class="fa fa-cart-arrow-down" target="_blank"></i> <span>Transaksi Aktif</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('transaksi.baru')); ?>">
                    <i class="fa fa-cart-arrow-down" target="_blank"></i> <span>Transaksi Baru</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('retur.index')); ?>">
                    <i class="fa fa-refresh" target="_blank"></i> <span>Transaksi Retur Penjualan</span>
                </a>
            </li>
            <?php endif; ?>
            <?php endif; ?>
            <?php endif; ?>
        </ul>
    </section>
    <!-- /.sidebar -->
</aside><?php /**PATH C:\laragon\www\apotek\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>