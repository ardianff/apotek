<?php $__env->startSection('title'); ?>
    Transaksi Pembelian
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<style>
    .tampil-bayar {
        font-size: 5em;
        text-align: center;
        height: 100px;
    }

    .tampil-terbilang {
        padding: 10px;
        background: #f0f0f0;
    }

    .table-pembelian tbody tr:last-child {
        display: none;
    }

    @media(max-width: 768px) {
        .tampil-bayar {
            font-size: 3em;
            height: 70px;
            padding-top: 5px;
        }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    ##parent-placeholder-6e5ce570b4af9c70279294e1a958333ab1037c86##
    <li class="active">Transaksi Pembelian</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="box">
            <div class="box-header with-border">
                <div class="row">
                    <div class="col-lg-2">

                        <table>
                            <tr>
                                <td>Supplier</td>
                                <td>: <?php echo e($supplier->nama_supplier); ?></td>
                            </tr>
                            <tr>
                                <td>Telepon</td>
                                <td>: <?php echo e($supplier->telepon); ?></td>
                            </tr>
                            <tr>
                                <td>Alamat</td>
                                <td>: <?php echo e($supplier->alamat); ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-lg-3">
                    <div class="form-group row">
                        <label for="no_faktur" class="col-lg-4 control-label">NO Faktur</label>
                        <div class="col-lg-8">
                            <input type="text"  id="no_faktur" class="form-control " >
                        </div>
                    </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="form-group row">
                            <label for="tgl_faktur" class="col-lg-4 control-label">Tanggal Faktur</label>
                            <div class="col-lg-8">
                                <input type="text" id="tgl_faktur" class="form-control datepicker" >
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="form-group row">
                            <label for="tempo" class="col-lg-4 control-label">Tanggal Jatuh Tempo</label>
                            <div class="col-lg-8">
                                <input type="text"  id="tempo" class="form-control datepicker" >
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="box-body">
                    
                <form class="form-produk">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label for="kode_produk" class="col-lg-2">Kode Produk</label>
                        <div class="col-lg-5">
                            <div class="input-group">
                                <input type="hidden" name="id_pembelian" id="id_pembelian" value="<?php echo e($pembelian->id); ?>">
                                <input type="hidden" name="id_produk" id="id_produk">
                                <input type="text" class="form-control" name="kode_produk" id="kode_produk">
                                <span class="input-group-btn">
                                    <button onclick="tampilProduk()" class="btn btn-info btn-flat" type="button"><i class="fa fa-arrow-right"></i></button>
                                </span>
                            </div>
                        </div>
                    </div>
                </form>
<div class="table-responsive">

    <table class="table table-stiped table-bordered table-pembelian">
        <thead>
            <th width="3%">No</th>
            <th width="5%">Kode</th>
            <th width="25%">Nama</th>
            <th width="5%">Jumlah</th>
            <th width="5%">isi</th>
            <th style="width:7em">Harga non PPN</th>
            <th style="width:7em">Harga Beli PPN</th>
            
            <th width="5%">Diskon</th>
            <th style="width:7em">ED</th>
                        <th style="width:7em">Batch</th>
                        <th style="width:7em">Subtotal</th>
                        <th width="3%"><i class="fa fa-cog"></i></th>
                    </thead>
                </table>
        </div>

                <div class="row">
                    <div class="col-lg-7">
                        <div class="tampil-bayar bg-primary"></div>
                        <div class="tampil-terbilang"></div>
                    </div>
                    <div class="col-lg-5">
                        <form action="<?php echo e(route('pembelian.store')); ?>" class="form-pembelian" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id_pembelian" value="<?php echo e($pembelian->id); ?>">
                            <input type="hidden" name="total" id="total">
                            <input type="hidden" name="bayar" id="bayar">
                            <input type="hidden" name="no_faktur" id="isino_faktur" required>
                            <input type="hidden" name="tgl_faktur" id="isitgl_faktur" required>
                            <input type="hidden" name="tempo" id="tgl_tempo">

                            <div class="form-group row">
                                <label for="total_item" class="col-lg-3 control-label">Total Item</label>
                                <div class="col-lg-8">
                                    <input type="text" name="total_item" id="total_item" class="form-control" readonly>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="totalrp" class="col-lg-3 control-label">Total</label>
                                <div class="col-lg-8">
                                    <input type="text" id="totalrp" class="form-control" readonly>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="diskon" class="col-lg-3 control-label">Diskon</label>
                                <div class="col-lg-8">
                                    <input type="number" name="diskon" id="diskon" class="form-control" value="<?php echo e($diskon); ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="" class="col-lg-3 control-label">Metode Pembayaran</label>
                                <div class="col-lg-8">
                                    <select name="metode" id="" class="form-control">
                                        <?php $__currentLoopData = $metode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                        <option value="<?php echo e($metod->id); ?>"><?php echo e($metod->metode); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="bayar" class="col-lg-3 control-label">Bayar</label>
                                <div class="col-lg-8">
                                    <input type="text" id="bayarrp" class="form-control">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="box-footer">
                <button type="submit" class="btn btn-primary btn-md btn-flat pull-right btn-simpan "><i class="fa fa-floppy-o"></i> Simpan Transaksi</button>
                <a href="<?php echo e(route('pembelian.cancel',$pembelian->id)); ?>" type="button" class="btn btn-warning btn-md btn-flat pull-right " style="margin-right:7em;"><i class="fa fa-arrow-left"></i> Batal </a>
            </div>
        </div>
    </div>
</div>

<?php if ($__env->exists('pembelian_detail.produk')) echo $__env->make('pembelian_detail.produk', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    let table, table2;
    
    $(function () {
        $('body').addClass('sidebar-collapse');

        $('.uang').mask('000.000.000.000',{reverse:true});

        $('.datepicker').datepicker({
           format: 'dd-mm-yyyy',
        //    startDate: '1d',
           autoclose: true
       });
      
        table = $('.table-pembelian').DataTable({
            responsive: true,
            processing: true,
            serverSide: true,
            autoWidth: false,
            ajax: {
                url: '<?php echo e(route('pembelian_detail.data', $pembelian->id)); ?>',
            },
            columns: [
                {data: 'DT_RowIndex', searchable: false, sortable: false},
                {data: 'kode_produk'},
                {data: 'nama_produk'},
                {data: 'jumlah'},
                {data: 'isi'},
                {data: 'harga_nonppn'},
                {data: 'harga_beli'},
                // {data: 'harga_jual'},
                {data: 'diskon'},
                {data: 'ed'},
                {data: 'batch'},
                {data: 'subtotal'},
                {data: 'aksi', searchable: false, sortable: false},
            ],
            dom: 'Brt',
            bSort: false,
            paginate: false
        })
        .on('draw.dt', function () {
            loadForm($('#diskon').val());
        });
        table2 = $('.table-produk').DataTable();

   

        $(document).on('input', '.quantity', function () {
            let id = $(this).data('id');
            let jumlah = parseInt($(this).val());

            // if (jumlah < 1) {
            //     $(this).val(1);
            //     alert('Jumlah tidak boleh kurang dari 1');
            //     return;
            // }
            if (jumlah > 100000) {
                $(this).val(100000);
                alert('Jumlah tidak boleh lebih dari 10000');
                return;
            }

            $.post(`<?php echo e(url('/pembelian_detail')); ?>/${id}`, {
                    '_token': $('[name=csrf-token]').attr('content'),
                    '_method': 'put',
                    'jumlah': jumlah
                })
                .done(response => {
                    // $(this).on('mouseout', function () {
                        table.ajax.reload(() => loadForm($('#diskon').val()));
                    // });
                })
                
        });
        $(document).on('input', '.isi', function () {
            let id = $(this).data('id');
            let isi = parseInt($(this).val());

            // if (jumlah < 1) {
            //     $(this).val(1);
            //     alert('Jumlah tidak boleh kurang dari 1');
            //     return;
            // }
            if (isi > 100000) {
                $(this).val(100000);
                alert('isi tidak boleh lebih dari 10000');
                return;
            }

            $.post(`<?php echo e(url('/pembelian_detail/isi')); ?>/${id}`, {
                    '_token': $('[name=csrf-token]').attr('content'),
                    '_method': 'put',
                    'isi': isi
                })
                .done(response => {
                    $(this).on('mouseout', function () {
                        table.ajax.reload(() => loadForm($('#diskon').val()));
                    });
                })
                
        });

        $(document).on('input', '.diskon_item', function () {
            let id = $(this).data('id');
            let diskon = $(this).val();
            if (diskon < 0) {
                $(this).val(0);
                alert('diskon tidak boleh kurang dari 1');
                return;
            }
            $.post(`<?php echo e(url('/pembelian_detail/diskon_item')); ?>/${id}`, {
                    '_token': $('[name=csrf-token]').attr('content'),
                    '_method': 'put',
                    'diskon': diskon
                })
                .done(response => {
                    $(this).on('mouseout', function () {
                        table.ajax.reload(() => loadForm($('#diskon').val()));
                    });
                })
                
        });

        $(document).on('change', '.harga_beli', function () {
            let id = $(this).data('id');
            let a = $(this).val();
            let harga_beli=a.replace('.','');
           
            $.post(`<?php echo e(url('/pembelian_detail/harga_beli')); ?>/${id}`, {
                    '_token': $('[name=csrf-token]').attr('content'),
                    '_method': 'put',
                    'harga_beli': harga_beli
                })
                .done(response => {
                    $(this).on('mouseout', function () {
                        table.ajax.reload(() => loadForm($('#diskon').val()));
                    });
                })
                
        });

        $(document).on('change', '.subtotal', function () {
            let id = $(this).data('id');
            let a = $(this).val();
            let subtotal=a.replace('.','');
            
            $.post(`<?php echo e(url('/pembelian_detail/subtotal')); ?>/${id}`, {
                    '_token': $('[name=csrf-token]').attr('content'),
                    '_method': 'put',
                    'subtotal': subtotal
                })
                .done(response => {
                    $('.total').val(response.total)
                    $(this).on('mouseout', function () {
                        table.ajax.reload(() => loadForm($('#diskon').val()));
                    });
                })
                
        });

        $(document).on('change', '.harga_nonppn', function () {
            let id = $(this).data('id');
            let a = $(this).val();
            let harga_nonppn=a.replace('.','');
            
            $.post(`<?php echo e(url('/pembelian_detail/harga_nonppn')); ?>/${id}`, {
                    '_token': $('[name=csrf-token]').attr('content'),
                    '_method': 'put',
                    'harga_nonppn': harga_nonppn
                })
                .done(response => {
                    $(this).on('mouseout', function () {
                        table.ajax.reload(() => loadForm($('#diskon').val()));
                    });
                })
                
        });

        $(document).on('change', '.ed', function () {
            let id = $(this).data('id');
            let ed = $(this).val();
          
            $.post(`<?php echo e(url('/pembelian_detail/ed')); ?>/${id}`, {
                    '_token': $('[name=csrf-token]').attr('content'),
                    '_method': 'put',
                    'ed': ed
                })
                .done(response => {
                    $(this).on('mouseout', function () {
                        table.ajax.reload(() => loadForm($('#diskon').val()));
                    });
                })
                
        });

        $(document).on('change', '.batch', function () {
            let id = $(this).data('id');
            let batch = $(this).val();
          
            $.post(`<?php echo e(url('/pembelian_detail/batch')); ?>/${id}`, {
                    '_token': $('[name=csrf-token]').attr('content'),
                    '_method': 'put',
                    'batch': batch
                })
                .done(response => {
                    $(this).on('mouseout', function () {
                        table.ajax.reload(() => loadForm($('#diskon').val()));
                    });
                })
                
        });

        $(document).on('input', '#diskon', function () {
            if ($(this).val() == "") {
                $(this).val(0).select();
            }

            loadForm($(this).val());
        });
        $(document).on('input', '#no_faktur', function () {
            let no=$(this).val();
          $('#isino_faktur').val(no);

        });
        $(document).on('change', '#tgl_faktur', function () {
            let tgl=$(this).val();
          $('#isitgl_faktur').val(tgl);

        });
        $(document).on('change', '#tempo', function () {
            let tgl=$(this).val();
          $('#tgl_tempo').val(tgl);

        });

        $('.btn-simpan').on('click', function () {
            let temp=$('#tgl_tempo').val();
            let tglfak=$('#isitgl_faktur').val();
            let nofak=$('#isino_faktur').val();
            if (!nofak) {
                alert('Nomer faktur  wajib di isi');
            }else if(!tglfak){
                alert('tanggal faktur wajib di isi');
            }else if (!temp) {
                alert('tanggal jatuh tempo wajib di isi');
                
            }else{

                $('.form-pembelian').submit(); 
            }
        });
    });

    function tampilProduk() {
        $('#modal-produk').modal('show');
    }

    function hideProduk() {
        $('#modal-produk').modal('hide');
    }

    function pilihProduk(id, kode) {
        $('#id_produk').val(id);
        $('#kode_produk').val(kode);
        hideProduk();
        tambahProduk();
    }

    function tambahProduk() {
        $.post('<?php echo e(route('pembelian_detail.store')); ?>', $('.form-produk').serialize())
            .done(response => {
                $('#kode_produk').focus();
                table.ajax.reload(() => loadForm($('#diskon').val()));
            })
            .fail(errors => {
                alert('Tidak dapat menyimpan data');
                return;
            });
    }

    function deleteData(url) {
        if (confirm('Yakin ingin menghapus data terpilih?')) {
            $.post(url, {
                    '_token': $('[name=csrf-token]').attr('content'),
                    '_method': 'delete'
                })
                .done((response) => {
                    table.ajax.reload(() => loadForm($('#diskon').val()));
                })
                .fail((errors) => {
                    alert('Tidak dapat menghapus data');
                    return;
                });
        }
    }
   

    function loadForm(diskon = 0) {
        $('#total').val($('.total').text());
        $('#total_item').val($('.total_item').text());

        $.get(`<?php echo e(url('/pembelian_detail/loadform')); ?>/${diskon}/${$('.total').text()}`)
            .done(response => {
                $('#totalrp').val('Rp. '+ response.totalrp);
                $('#bayarrp').val('Rp. '+ response.bayarrp);
                $('#bayar').val(response.bayar);
                $('.tampil-bayar').text('Rp. '+ response.bayarrp);
                $('.tampil-terbilang').text(response.terbilang);
            })
            .fail(errors => {
                alert('Tidak dapat menampilkan data');
                return;
            })
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\apotek\resources\views/pembelian_detail/index.blade.php ENDPATH**/ ?>