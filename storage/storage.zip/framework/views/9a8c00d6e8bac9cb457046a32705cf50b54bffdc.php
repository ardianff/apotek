<?php $__env->startSection('title'); ?>
    Transaksi Penjualan
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<style>
    .tampil-bayar {
        font-size: 5em;
        text-align: center;
        height: 100px;
    }

    .tampil-terbilang {
        padding: 10px;
        background: #f0f0f0;
    }

    .table-penjualan tbody tr:last-child {
        display: none;
    }

    @media(max-width: 768px) {
        .tampil-bayar {
            font-size: 3em;
            height: 70px;
            padding-top: 5px;
        }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    ##parent-placeholder-6e5ce570b4af9c70279294e1a958333ab1037c86##
    <li class="active">Transaksi Penjaualn</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-lg-12">
        <div class="box">
            <div class="box-body">
            

                            <form class="form-produk">
                                <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label for="kode_produk" class="col-lg-2">Kode Produk</label>
                        <div class="col-lg-5">
                            <div class="input-group">
                                <input type="hidden" name="penjualan_id" id="penjualan_id" value="<?php echo e($penjualan_id); ?>">
                                <input type="hidden" name="produk_id" id="produk_id">
                                <input type="text" class="form-control" name="kode_produk" id="kode_produk">
                                <span class="input-group-btn">
                                    <button onclick="tampilProduk()" class="btn btn-info btn-flat" type="button"><i class="fa fa-arrow-right"></i></button>
                                </span>
                            </div>
                        </div>
                    </div>
                </form>
                      
                <div class="row">
                    <div class="col-lg-8">
                        
                 <div class="row">
                    <div class="col-lg-12">

                    
                <table class="table table-stiped table-bordered table-penjualan">
                    <thead>
                        <th width="5%">No</th>
                        <th>Kode</th>
                        <th>Nama</th>
                        <th>Harga</th>
                        <th width="15%">Jumlah</th>
                        <th>Diskon</th>
                        <th>Subtotal</th>
                        <th width="15%"><i class="fa fa-cog"></i></th>
                    </thead>
                </table>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="tampil-bayar bg-primary"></div>
                <div class="tampil-terbilang"></div>
                <?php if(\Session::has('gagal')): ?>
<div class="alert alert-warning alert-dismissible">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true"><i class="fa fa-times" aria-hidden="true"></i></button>
    <h4><i class="icon fa fa-info"></i> <?php echo e(\Session::get('gagal')); ?></h4>
    
    </div>
<?php endif; ?>
            </div> 
            </div> 

            </div> 
            <div class="col-lg-4">
                <form action="<?php echo e(route('transaksi.simpan')); ?>" class="form-penjualan" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="penjualan_id" value="<?php echo e($penjualan_id); ?>">
                    <input type="hidden" name="total" id="total">
                    <input type="hidden" name="total_item" id="total_item">
                    <input type="hidden" name="bayar" id="bayar">

                    <div class="form-group row">
                        <label for="totalrp" class="col-lg-4 control-label">Total</label>
                        <div class="col-lg-8">
                            <input type="text" id="totalrp" class="form-control" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="kode_diskon" class="col-lg-4 control-label">Kode Diskon</label>
                        <div class="col-lg-8">
                            <div class="input-group">
                                <input type="text" class="form-control" id="kode_diskon" value="">
                                <span class="input-group-btn">
                                    <button onclick="tampilpotongan()" class="btn btn-info btn-flat" type="button"><i class="fa fa-arrow-right"></i></button>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="jasa" class="col-lg-4 control-label">Pilih Jasa</label>
                        <div class="col-lg-8">
                            <div class="input-group">
                                <input type="text" class="form-control" id="jasa" name="jasa" value="<?php echo e($penjualan->jasa); ?>">
                                <span class="input-group-btn">
                                    <button onclick="tampiljasa()" class="btn btn-info btn-flat" type="button"><i class="fa fa-user-md"></i></button>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="member" class="col-lg-4 control-label">Pilih member</label>
                        <div class="col-lg-8">
                            <div class="input-group">
                                <input type="text" class="form-control" id="member" name="member" placeholder="member">
                                <input type="hidden" class="form-control" id="member_id" name="member_id" value="0">
                                <span class="input-group-btn">
                                    <button onclick="tampilMember()" class="btn btn-info btn-flat" type="button"><i class="fa fa-user"></i></button>
                                </span>
                                       
                                    </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="diskon" class="col-lg-4 control-label">Diskon</label>
                        <div class="col-lg-8">
                            <input type="number" name="diskon" id="diskon" class="form-control" 
                                value="<?php echo e($penjualan->diskon); ?>" 
                                readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="bayarrp" class="col-lg-4 control-label">Bayar</label>
                        <div class="col-lg-8">
                            <input type="text" id="bayarrp" class="form-control uang" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="" class="col-lg-4 control-label">Metode Pembayaran</label>
                        <div class="col-lg-8">
                            <select name="metode_id" id="" class="form-control">
                                <?php $__currentLoopData = $metode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                <option value="<?php echo e($metod->id); ?>"><?php echo e($metod->metode); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="diterima" class="col-lg-4 control-label">Diterima</label>
                        <div class="col-lg-8">
                            <input type="text" id="diterima" class="form-control uang" name="diterima" value="<?php echo e($penjualan->diterima ?? 0); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="kembali" class="col-lg-4 control-label">Kembali</label>
                        <div class="col-lg-8">
                            <input type="text" id="kembali" name="kembali" class="form-control" value="0" readonly>
                        </div>
                    </div>
                </form>
            </div>   
        </div> 
        </div> 
               
            

            <div class="box-footer">
                <button type="submit" class="btn btn-success btn-md pull-right btn-simpan" ><i class="fa fa-floppy-o"></i> Simpan Transaksi</button>
                <a href="<?php echo e(route('penjualan.cancel',$penjualan_id)); ?>" type="submit" class="btn btn-warning btn-md pull-left" style="margin-right:4em;" ><i class="fa fa-undo"></i> Batal </a>
            </div>
        </div>
    </div>
</div>

<?php if ($__env->exists('penjualan_detail.produk')) echo $__env->make('penjualan_detail.produk', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if ($__env->exists('penjualan_detail.jasa')) echo $__env->make('penjualan_detail.jasa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if ($__env->exists('penjualan_detail.member')) echo $__env->make('penjualan_detail.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if ($__env->exists('member.form')) echo $__env->make('member.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if ($__env->exists('penjualan_detail.potongan')) echo $__env->make('penjualan_detail.potongan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    let table, table2, table3;

    $(function () {
        $('body').addClass('sidebar-collapse');

        table = $('.table-penjualan').DataTable({
            responsive: true,
            processing: true,
            serverSide: true,
            autoWidth: false,
            ajax: {
                url: '<?php echo e(route('transaksi.data', $penjualan_id)); ?>',
            },
            columns: [
                {data: 'DT_RowIndex', searchable: false, sortable: false},
                {data: 'kode_produk'},
                {data: 'nama_produk'},
                {data: 'harga_jual'},
                {data: 'jumlah'},
                {data: 'diskon'},
                {data: 'subtotal'},
                {data: 'aksi', searchable: false, sortable: false},
            ],
            dom: 'Brt',
            bSort: false,
            paginate: false
        })
        .on('draw.dt', function () {
            loadForm($('#diskon').val(),$('#jasa').val());
            setTimeout(() => {
                $('#diterima').trigger('input');
            }, 300);
        });
        table2 = $('.table-produk').DataTable();
        table3 = $('.table-member').DataTable();

        $(document).on('change', '.quantity', function () {
            let id = $(this).data('id');
            let jumlah = parseInt($(this).val());

            if (jumlah < 1) {
                $(this).val(1);
                alert('Jumlah tidak boleh kurang dari 1');
                return;
            }
            if (jumlah > 10000) {
                $(this).val(10000);
                alert('Jumlah tidak boleh lebih dari 10000');
                return;
            }

            $.post(`<?php echo e(url('/transaksi')); ?>/${id}`, {
                    '_token': $('[name=csrf-token]').attr('content'),
                    '_method': 'put',
                    'jumlah': jumlah
                })
                .done(response => {
                    // $(this).on('mouseout', function () {
                        table.ajax.reload(() => loadForm($('#diskon').val()));
                    // });
                })
                
        });

        $(document).on('input', '#diskon', function () {
            if ($(this).val() == "") {
                $(this).val(0).select();
            }

            loadForm($(this).val());
        });

     
      

        $('#diterima').on('input', function () {
            if ($(this).val() == "") {
                $(this).val(0).select();
            }
           
            loadForm($('#diskon').val(),$('#jasa').val(), $(this).val());
        }).focus(function () {
            $(this).select();
        });

        $('.btn-simpan').on('click', function () {
           
                        $('.form-penjualan').submit();

        });
    });

    function tampilProduk() {
        $('#modal-produk').modal('show');
    }

    function hideProduk() {
        $('#modal-produk').modal('hide');
    }

    function pilihProduk(id, kode) {
        $('#produk_id').val(id);
        $('#kode_produk').val(kode);
        hideProduk();
        tambahProduk();
    }

   

    function tambahProduk() {
        $.post('<?php echo e(route('transaksi.store')); ?>', $('.form-produk').serialize())
            .done(response => {
                $('#kode_produk').focus();
                table.ajax.reload(() => loadForm($('#diskon').val(),$('#jasa').val()));
            })
            .fail(errors => {
                alert('Tidak dapat menyimpan data');
                return;
            });
    }
   
    function tampilpotongan() {
        $('#modal-potongan').modal('show');
    }

    function pilihpotongan(nominal, kode) {
        $('#diskon').val(nominal);
        $('#kode_diskon').val(kode);
        loadForm($('#diskon').val(),$('#jasa').val());
        $('#diterima').val(0).focus().select();
        hidepotongan();
    }

    function hidepotongan() {
        $('#modal-potongan').modal('hide');
    }


    function tampiljasa() {
        $('#modal-jasa').modal('show');
    }

    function pilihjasa(nom) {
       
        $('#jasa').val(nom);
    
        loadForm($('#diskon').val(),$('#jasa').val());
        $('#diterima').val(0).focus().select();
        hidejasa();
    }
    
    function hidejasa() {
        $('#modal-jasa').modal('hide');
    }
    function tampilMember() {
        $('#modal-member').modal('show');
    }
    
    function pilihMember(id,nama) {
        $('#member').val(nama);
        $('#member_id').val(id);

        hidemember();
    }
    

    function hidemember() {
        $('#modal-member').modal('hide');
    }
    function deleteData(url) {
        if (confirm('Yakin ingin menghapus data terpilih?')) {
            $.post(url, {
                    '_token': $('[name=csrf-token]').attr('content'),
                    '_method': 'delete'
                })
                .done((response) => {
                    table.ajax.reload(() => loadForm($('#diskon').val()));
                })
                .fail((errors) => {
                    alert('Tidak dapat menghapus data');
                    return;
                });
        }
    }
    

    function loadForm(diskon = 0,jasa= 0, diterima = 0) {
        $('#total').val($('.total').text());
        $('#total_item').val($('.total_item').text());

        $.get(`<?php echo e(url('/transaksi/loadform')); ?>/${diskon}/${jasa}/${$('.total').text()}/${diterima}`)
            .done(response => {
                $('#totalrp').val('Rp. '+ response.totalrp);
                $('#bayarrp').val(response.bayarrp);
                $('#bayar').val(response.bayar);
                $('.tampil-bayar').text('Bayar: Rp. '+ response.bayarrp);
                $('.tampil-terbilang').text(response.terbilang);

                $('#kembali').val('Rp.'+ response.kembalirp);
                if ($('#diterima').val() != 0) {
                    $('.tampil-bayar').text('Kembali: Rp. '+ response.kembalirp);
                    $('.tampil-terbilang').text(response.kembali_terbilang);
                }
            })
            .fail(errors => {
                alert('Tidak dapat menampilkan data');
                return;
            })
    }
    function addMember(url) {
        $('#modal-form').modal('show');
        $('#modal-form .modal-title').text('Tambah Member');

        $('#modal-form form')[0].reset();
        $('#modal-form form').attr('action', url);
        $('#modal-form [name=_method]').val('post');
    }

    $('.uang').mask('0.000.000.000.000',{reverse:true})
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\apotek\resources\views/penjualan_detail/index.blade.php ENDPATH**/ ?>