<div class="modal fade" id="modal-member" tabindex="-1" role="dialog" aria-labelledby="modal-member">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Pilih member</h4>
                <h5 class="text-danger"> Daftar new Member 

                    <button onclick="addMember('<?php echo e(route('member.store')); ?>')" class="btn btn-success btn-xs btn-flat"><i class="fa fa-plus-circle"></i> Tambah Member Baru</button>
                </h5>
            </div>
            <div class="modal-body">
                <table class="table table-striped table-bordered table-member">
                    <thead>
                        <th width="5%">No</th>
                        <th>Kode member</th>
                        <th>Nama member</th>
                        <th>PT member</th>
                        <th>telepon</th>
                        <th>alamat</th>
                      
                        <th><i class="fa fa-cog"></i></th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td width="5%"><?php echo e($key+1); ?></td>
                                <td><?php echo e($item->kode_member); ?></td>
                                <td><?php echo e($item->nama); ?></td>
                                <td><?php echo e($item->pt); ?></td>
                                <td><?php echo e($item->telepon); ?></td>
                                <td><?php echo e($item->alamat); ?></td>
                               
                                <td>
                                    <a href="#" class="btn btn-primary btn-xs btn-flat"
                                        onclick="pilihMember('<?php echo e($item->id); ?>','<?php echo e($item->nama); ?>')">
                                        <i class="fa fa-check-circle"></i>
                                        Pilih
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\apotek\resources\views/penjualan_detail/member.blade.php ENDPATH**/ ?>