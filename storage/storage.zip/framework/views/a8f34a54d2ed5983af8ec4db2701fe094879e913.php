<div class="modal fade" id="modal-produk" tabindex="-1" role="dialog" aria-labelledby="modal-produk">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Pilih Obat</h4>
            </div>
            <div class="modal-body">
                <div class="table-responsive">

                    <table class="table table-striped table-bordered table-produk">
                        <thead>
                        <th width="5%">No</th>
                      
                        <th>Nama</th>
                        <th width="5%">Stok</th>
                        <th width="5%">Satuan</th>
                        <th width="5%">Lokasi</th>
                        <th width="5%">Expired date</th>
                        <th>Harga Jual</th>
                        <th width="5%"><i class="fa fa-cog"></i></th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $obat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td width="5%"><?php echo e($key+1); ?></td>
                              
                                <td><?php echo e($item->nama_obat); ?></td>
                                <td><?php echo e($item->stock); ?></td>
                                <td><?php echo e($item->satuan ?? 0); ?></td>
                                <td><?php echo e($item->lokasi->name?? 'belum ada lokasi'); ?></td>
                                <td style="max-width: 50px"><?php echo e($item->ed); ?></td>
                                <td><?php echo e($item->harga_jual); ?></td>
                                <td>
                                    <a href="#" class="btn btn-primary btn-xs btn-flat"
                                        onclick="pilihProduk('<?php echo e($item->id); ?>', '<?php echo e($item->kode_obat); ?>')">
                                        <i class="fa fa-check-circle"></i>
                                        Pilih
                                    </a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\apotek\resources\views/penjualan_detail/produk.blade.php ENDPATH**/ ?>