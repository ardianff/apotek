<div class="modal fade " id="modal-form" tabindex="-1" role="dialog" aria-labelledby="modal-form">
    <div class="modal-dialog modal-lg " role="document">
        <form action="" method="post" class="form-horizontal">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"></h4>
                </div>
        <div class="modal-body">
            
            <div class="nav-tabs-custom">
                <ul class="nav nav-tabs">
                    <li class="active">
                    <a  href="#stok" data-toggle="tab"  aria-expanded="false">Stok Obat</a>
                    </li>
              
                <li class="">
                    <a  href="#detil" data-toggle="tab" aria-expanded="true">Data Obat</a>
                    </li>
                  
               
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="stok">
                        <div class="form-group row">
                            <label for="ed" class="col-lg-2 col-lg-offset-1 control-label">ed</label>
                            <div class="col-lg-6">
                                <input type="text"  id="ed" class="form-control " value="0" disabled>
                                <input type="date" name="ed" id="ed" class="form-control " value="0" >
                                <span class="help-block with-errors"></span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="batch" class="col-lg-2 col-lg-offset-1 control-label">batch</label>
                            <div class="col-lg-6">
                                <input type="text" name="batch" id="batch" class="form-control " value="" >
                                <span class="help-block with-errors"></span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="stock" class="col-lg-2 col-lg-offset-1 control-label">Stock</label>
                            <div class="col-lg-6">
                                <input type="number" name="stock" id="stock" class="form-control " value="0" >
                                <span class="help-block with-errors"></span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="isi" class="col-lg-2 col-lg-offset-1 control-label">isi</label>
                            <div class="col-lg-6">
                                <input type="number" name="isi" id="isi" class="form-control" value="0" >
                                <span class="help-block with-errors"></span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="stok_minim" class="col-lg-2 col-lg-offset-1 control-label">Stok Minimal</label>
                            <div class="col-lg-6">
                                <input type="text" name="stok_minim" id="stok_minim" class="form-control" value="0" >
                                <span class="help-block with-errors"></span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="diskon" class="col-lg-2 col-lg-offset-1 control-label">Diskon</label>
                            <div class="col-lg-6">
                                <input type="text" name="diskon" id="diskon" class="form-control" value="0" >
                                <span class="help-block with-errors"></span>
                            </div>
                        </div>
                     
                        <div class="form-group row">
                            <label for="harga_beli" class="col-lg-2 col-lg-offset-1 control-label">harga_beli</label>
                            <div class="col-lg-6">
                                <input type="text" name="harga_beli" id="harga_beli" class="form-control uang">
                                <span class="help-block with-errors"></span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="margin" class="col-lg-2 col-lg-offset-1 control-label">margin</label>
                            <div class="col-lg-6">
                                <input type="text" name="margin" id="margin" class="form-control">
                                <span class="help-block with-errors"></span>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="harga_jual" class="col-lg-2 col-lg-offset-1 control-label">harga_jual</label>
                            <div class="col-lg-6">
                                <input type="text" name="harga_jual" id="harga_jual" class="form-control uang">
                                <span class="help-block with-errors"></span>
                            </div>
                        </div>
                       
                       
                    </div>
                <div class="tab-pane " id="detil">
                   
                    <div class="form-group row">
                        <label for="nama_obat" class="col-lg-2 col-lg-offset-1 control-label">Nama Obat</label>
                        <div class="col-lg-6">
                            <input type="text" name="nama_obat" id="nama_obat" class="form-control" required autofocus>
                            <span class="help-block with-errors"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="satuan" class="col-lg-2 col-lg-offset-1 control-label">satuan</label>
                        <div class="col-lg-6">
                            <input type="text" name="satuan" id="satuan" class="form-control" >
                            <span class="help-block with-errors"></span>
                        </div>
                    </div>
                    <input type="hidden" name="racikan" value="0">
                    
                    <div class="form-group row">
                        <label for="lokasi_id" class="col-lg-2 col-lg-offset-1 control-label">lokasi</label>
                        <div class="col-lg-6">
                            <select name="lokasi_id" id="lokasi_id" class="form-control" >
                                <?php $__currentLoopData = $lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lokal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($lokal->id); ?>"><?php echo e($lokal->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="help-block with-errors"></span>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label for="kategori_id" class="col-lg-2 col-lg-offset-1 control-label">kategori</label>
                        <div class="col-lg-6">
                            <select name="kategori_id" id="kategori_id" class="form-control" >
                                <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($gl->id); ?>"><?php echo e($gl->nama_kategori); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="help-block with-errors"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="golongan_id" class="col-lg-2 col-lg-offset-1 control-label">golongan</label>
                        <div class="col-lg-6">
                            <select name="golongan_id" id="golongan_id" class="form-control" >
                                <?php $__currentLoopData = $golongan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($gl->id); ?>"><?php echo e($gl->nama_gol); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="help-block with-errors"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="jenis_id" class="col-lg-2 col-lg-offset-1 control-label">jenis</label>
                        <div class="col-lg-6">
                            <select name="jenis_id" id="jenis_id" class="form-control" >
                                <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jns): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($jns->id); ?>"><?php echo e($jns->nama_jenis); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="help-block with-errors"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="konsi" class="col-lg-2 col-lg-offset-1 control-label">Konsinasi</label>
                        <div class="col-lg-6">
                            <select name="konsi" id="konsi" class="form-control" >
                               
                                <option value="0">tidak</option>
                                <option value="1">Ya</option>
                            </select>
                            <span class="help-block with-errors"></span>
                        </div>
                    </div>
              
                    <div class="form-group row">
                        <label for="merk" class="col-lg-2 col-lg-offset-1 control-label">merek</label>
                        <div class="col-lg-6">
                            <input type="text" name="merk" id="merk" class="form-control">
                            <span class="help-block with-errors"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="kandungan" class="col-lg-2 col-lg-offset-1 control-label">kandungan</label>
                        <div class="col-lg-6">
                            <input type="text" name="kandungan" id="kandungan" class="form-control">
                            <span class="help-block with-errors"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="kegunaan" class="col-lg-2 col-lg-offset-1 control-label">kegunaan</label>
                        <div class="col-lg-6">
                            <input type="text" name="kegunaan" id="kegunaan" class="form-control">
                            <span class="help-block with-errors"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="dosis" class="col-lg-2 col-lg-offset-1 control-label">dosis</label>
                        <div class="col-lg-6">
                            <input type="text" name="dosis" id="dosis" class="form-control">
                            <span class="help-block with-errors"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="efek" class="col-lg-2 col-lg-offset-1 control-label">Efek Samping</label>
                        <div class="col-lg-6">
                            <input type="text" name="efek" id="efek" class="form-control">
                            <span class="help-block with-errors"></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="zat" class="col-lg-2 col-lg-offset-1 control-label">zat Prekursor Aktif</label>
                        <div class="col-lg-6">
                            <input type="text" name="zat" id="zat" class="form-control">
                            <span class="help-block with-errors"></span>
                        </div>
                    </div>
                </div>
                
               
                
               
                </div>
                
                </div>
    </div>
                <div class="modal-footer">
                    <button class="btn btn-sm btn-flat btn-primary"><i class="fa fa-save"></i> Simpan</button>
                    <button type="button" class="btn btn-sm btn-flat btn-warning" data-dismiss="modal"><i class="fa fa-arrow-circle-left"></i> Batal</button>
                </div>
            </div>
        </form>
    </div>
</div><?php /**PATH C:\laragon\www\apotek\resources\views/produk/form.blade.php ENDPATH**/ ?>