<div class="modal fade" id="modal-kasir" tabindex="-1" role="dialog" aria-labelledby="modal-kasir">
    <div class="modal-dialog modal-lg" role="document">
        <form action="<?php echo e(route('shift.buka_kasir')); ?>" method="post" class="form-horizontal">
            <?php echo csrf_field(); ?>

            <div class="modal-content">
                <div class="modal-header bg-primary">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                    <h2 class="modal-title bg-primary">Buka Shift</h2>
                </div>
                <div class="modal-body">
                   <div class="form-group row">
                       <label class="col-lg-2 col-lg-offset-1 control-label" for="shift">Pilih Shift</label>
                       <div class="col-lg-6">

                           <select id="shift" class="form-control" name="shift">
                               <option value="">Pilih shift</option>
                               <?php $__currentLoopData = $shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sh->id_shift); ?>"><?php echo e($sh->nama_sh); ?></option>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                   </div>
                    <div class="form-group row">
                        <label for="saldo-awal" class="col-lg-2 col-lg-offset-1 control-label">Saldo Awal Rp:</label>
                        <div class="col-lg-6">
                            <input type="text" name="saldo_awal" id="" class="form-control uang" required>
                            <span class="help-block with-errors"></span>
                        </div>
                    </div>
                    
                   
                </div>
                <div class="modal-footer">
                    <button class="btn btn-sm btn-flat btn-primary"><i class="fa fa-save"></i> Simpan</button>
                    <button type="button" class="btn btn-sm btn-flat btn-warning" data-dismiss="modal"><i class="fa fa-arrow-circle-left"></i> Batal</button>
                </div>
            </div>
        </form>
    </div>
</div>


<?php /**PATH C:\laragon\www\apotek\resources\views/kasir/modal_kasir.blade.php ENDPATH**/ ?>