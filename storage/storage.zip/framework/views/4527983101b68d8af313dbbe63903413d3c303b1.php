<?php $__env->startSection('title'); ?>
    Daftar Produk
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    ##parent-placeholder-6e5ce570b4af9c70279294e1a958333ab1037c86##
    <li class="active">Daftar Produk</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(Session::has('success')): ?>
<div class="alert alert-success" role="alert">
    <?php echo \Session::get('success'); ?>

  </div>
<?php endif; ?>
<div class="row">
    <div class="col-lg-12">
        <div class="box">
            <div class="box-header with-border">
                <div class="btn-group">
                    <button onclick="addForm('<?php echo e(route('produk.store')); ?>')" class="btn btn-success btn-sm "><i class="fa fa-plus-circle"></i> Tambah</button>
                    <button onclick="deleteSelected('<?php echo e(route('produk.delete_selected')); ?>')" class="btn btn-danger btn-sm "><i class="fa fa-trash"></i> Hapus</button>
                    <button onclick="cetakBarcode('<?php echo e(route('produk.cetak_barcode')); ?>')" class="btn btn-info btn-sm "><i class="fa fa-barcode"></i> Cetak Barcode</button>
                </div>
                    <button onclick="excel()" class="btn btn-success btn-sm"><i class="fa fa-file" aria-hidden="true"></i> Import Excel</button>
                    <button type="button" href="<?php echo e(URL::to('/')); ?>/file/template_produk.xlsx" target="_blank" class="btn btn-primary btn-sm"><i class="fa fa-download" aria-hidden="true"></i> Dwonload Template produk</button>
            </div>
            <div class="box-body table-responsive">
                <form action="" method="post" class="form-produk">
                    <?php echo csrf_field(); ?>
                    <table id="" class="table table-produk table-stiped table-bordered" >
                        <thead>
                            <th width="5%">
                                <input type="checkbox" name="select_all" id="select_all">
                            </th>
                            <th width="5%">No</th>
                            <th width="15%"><i class="fa fa-cog"></i></th>
                            <th>Nama</th>
                            <th>stok</th>
                            <th>satuan</th>
                            <th>lokasi</th>
                            <th>ed</th>
                            <th>Kode</th>
                            
                        </thead>
                        <tbody>
                        
                        </tbody>
                    </table>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<form action="<?php echo e(route('import.produk')); ?>" method="post" enctype="multipart/form-data">
<div class="modal fade" id="modal-excel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Import Excel</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <?php echo csrf_field(); ?>
<div class="form-group">
    <label for="importexcel">Import produk file excel</label>
    <input id="importexcel" class="form-control" type="file" name="import_produk">
</div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
    <button type="submit" class="btn btn-success">import</button>
</div>
</div>
</div>
</div>
</form>
<?php if ($__env->exists('produk.form')) echo $__env->make('produk.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $('.uang').mask('0.000.000.000.000',{reverse:true});
    
    function excel() {
        $('#modal-excel').modal('show');
    }
    let table,table2;

$(function () {
    table = $('.table-produk').DataTable({
        responsive: true,
        // processing: true,
        // serverSide: true,
        autoWidth: true,
        ajax: {
            url: '<?php echo e(route('produk.data')); ?>',
        },
        columns: [
            {data: 'select_all', searchable: false, sortable: false},
            {data: 'DT_RowIndex', searchable: false, sortable: false},
            {data: 'aksi', searchable: false, sortable: false},
            {data: 'nama_obat'},
            {data: 'stock'},
            {data: 'satuan'},
            {data: 'lokasi'},
            {data: 'ed'},
            {data: 'kode_obat'},
        ]
   
    });
    
       

    $('#modal-form').validator().on('submit', function (e) {
            if (! e.preventDefault()) {
                $.post($('#modal-form form').attr('action'), $('#modal-form form').serialize())
                    .done((response) => {
                        $('#modal-form').modal('hide');
                        table.ajax.reload();
                    })
                    .fail((errors) => {
                        alert('Tidak dapat menyimpan data');
                        return;
                    });
            }
        });

        $('[name=select_all]').on('click', function () {
            $(':checkbox').prop('checked', this.checked);
        });
        table1 = $('.table_stock').DataTable({
            processing: true,
            bSort: false,
            dom: 'Brt',
            columns: [
                {data: 'DT_RowIndex', searchable: false, sortable: false},
                {data: 'created_at'},
                {data: 'stock_awal'},
                {data: 'stok_out'},
                {data: 'stok_in'},
                {data: 'sisa'},
                {data: 'Ket_stock'},
                {data: 'user_id'},
            ]
        })
});

function kartu_stok(url) {
    
    $('#modal_kartu_stock').modal('show');
    table1.ajax.url(url);
        table1.ajax.reload();

}
    function addForm(url) {
        $('#modal-form').modal('show');
        $('#modal-form .modal-title').text('Tambah Data Obat');

        $('#modal-form form')[0].reset();
        $('#modal-form form').attr('action', url);
        $('#modal-form [name=_method]').val('post');
        $('#modal-form [name=nama_produk]').focus();
    }

    function editForm(url) {
        $('#modal-form').modal('show');
        $('#modal-form .modal-title').text('Edit Data Obat');

        $('#modal-form form')[0].reset();
        $('#modal-form form').attr('action', url);
        $('#modal-form [name=_method]').val('put');
        $('#modal-form [name=nama_produk]').focus();

        $.get(url)
            .done((response) => {
                $('#modal-form [name=kode_obat]').val(response.kode_obat);
                $('#modal-form [name=nama_obat]').val(response.nama_obat);
                $('#modal-form [name=satuan]').val(response.satuan);
                $('#modal-form [name=stock]').val(response.stock);
                $('#modal-form [name=isi]').val(response.isi);
                $('#modal-form [name=stok_minim]').val(response.stok_minim);
                $('#modal-form [name=margin]').val(response.margin);
                $('#modal-form [name=harga_beli]').val(response.harga_beli);
                $('#modal-form [name=harga_jual]').val(response.harga_jual);
                $('#modal-form [id=ed]').val(response.ed);
                $('#modal-form [name=batch]').val(response.batch);
                $('#modal-form [name=kategori_id]').val(response.kategori_id).attr('selcted',true);
                $('#modal-form [name=lokasi_id]').val(response.lokasi_id).attr('selcted',true);
                $('#modal-form [name=golongan_id]').val(response.golongan_id).attr('selcted',true);
                $('#modal-form [name=jenis_id]').val(response.jenis_id).attr('selcted',true);
                $('#modal-form [name=kandungan]').val(response.kandungan);
                $('#modal-form [name=kegunaan]').val(response.kegunaan);
                $('#modal-form [name=zat]').val(response.zat);
                $('#modal-form [name=merk]').val(response.merk);
                $('#modal-form [name=efek]').val(response.efek);
                $('#modal-form [name=dosis]').val(response.dosis);
            })
            .fail((errors) => {
                alert('Tidak dapat menampilkan data');
                return;
            });
    }

    function deleteData(url) {
        if (confirm('Yakin ingin menghapus data terpilih?')) {
            $.post(url, {
                    '_token': $('[name=csrf-token]').attr('content'),
                    '_method': 'delete'
                })
                .done((response) => {
                    table.ajax.reload();
                })
                .fail((errors) => {
                    alert('Tidak dapat menghapus data');
                    return;
                });
        }
    }

    function deleteSelected(url) {
        if ($('input:checked').length > 1) {
            if (confirm('Yakin ingin menghapus data terpilih?')) {
                $.post(url, $('.form-produk').serialize())
                    .done((response) => {
                        table.ajax.reload();
                    })
                    .fail((errors) => {
                        alert('Tidak dapat menghapus data');
                        return;
                    });
            }
        } else {
            alert('Pilih data yang akan dihapus');
            return;
        }
    }

    function cetakBarcode(url) {
        if ($('input:checked').length < 1) {
            alert('Pilih data yang akan dicetak');
            return;
        } else if ($('input:checked').length < 3) {
            alert('Pilih minimal 3 data untuk dicetak');
            return;
        } else {
            $('.form-produk')
                .attr('target', '_blank')
                .attr('action', url)
                .submit();
        }
    }
    $(function () {
        
       

       $('.datepicker').datepicker({
           format: 'dd-mm-yyyy',
           autoclose: true
       });

   });

   $(document).on('change', '#margin', function () {
            let margin =  parseInt($(this).val());
            let beli = $('#harga_beli').val();
            let harga_beli= beli.replace('.','');
            let a=parseInt(harga_beli);
          
            let mark=a * margin / 100 ;
            let hasil= a + mark;

            $('#harga_jual').mask('0.000.000.000.000',{reverse:true}).val(hasil).trigger('input');
                
        });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\apotek\resources\views/produk/index.blade.php ENDPATH**/ ?>